package com.audioplayer.app.ui

import android.os.SystemClock
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.audioplayer.app.Bookmark
import com.audioplayer.app.PlaybackExtras
import com.audioplayer.app.Store
import com.audioplayer.app.Track
import com.audioplayer.app.formatTime
import com.audioplayer.app.speedLabel
import kotlinx.coroutines.delay

data class PlayerUi(
    val isPlaying: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val position: Long = 0L,
    val duration: Long = 0L,
    val speed: Float = 1f,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
)

private fun Player.snapshot() = PlayerUi(
    isPlaying = isPlaying,
    mediaId = currentMediaItem?.mediaId,
    title = currentMediaItem?.mediaMetadata?.title?.toString().orEmpty(),
    position = currentPosition,
    duration = duration.coerceAtLeast(0L),
    speed = playbackParameters.speed,
    repeatMode = repeatMode,
    shuffle = shuffleModeEnabled,
)

@Composable
private fun rememberPlayerUi(player: Player?): PlayerUi {
    var ui by remember { mutableStateOf(PlayerUi()) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                ui = player.snapshot()
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }
    LaunchedEffect(player) {
        if (player == null) return@LaunchedEffect
        while (true) {
            ui = player.snapshot()
            delay(300)
        }
    }
    return ui
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    player: Player?,
    tracks: List<Track>,
    store: Store,
    onAddFiles: () -> Unit,
    onPlay: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
    onClear: () -> Unit,
    onShare: (Track) -> Unit,
) {
    val ui = rememberPlayerUi(player)
    val sleepEnd by PlaybackExtras.sleepEndAt.collectAsState()
    val sleepAtEnd by PlaybackExtras.sleepAtTrackEnd.collectAsState()

    var showSleep by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val currentTrack = tracks.firstOrNull { it.uri == ui.mediaId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Аудиоплеер") },
                actions = {
                    val sleepLabel = when {
                        sleepAtEnd -> "конец трека"
                        sleepEnd > 0 -> formatTime(sleepEnd - SystemClock.elapsedRealtime())
                        else -> null
                    }
                    if (sleepLabel != null) {
                        Text(
                            sleepLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = { showSleep = true }) {
                        Icon(
                            Icons.Default.Bedtime, "Таймер сна",
                            tint = if (sleepLabel != null) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onAddFiles) {
                        Icon(Icons.Default.Add, "Добавить файлы")
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Default.MoreVert, "Меню")
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Очистить список") },
                                enabled = tracks.isNotEmpty(),
                                onClick = { showMenu = false; confirmClear = true }
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (player != null && tracks.isNotEmpty()) {
                PlayerPanel(
                    player = player,
                    ui = ui,
                    onSpeed = { showSpeed = true },
                    onBookmarks = { if (ui.mediaId != null) showBookmarks = true },
                    onShare = { currentTrack?.let(onShare) },
                )
            }
        }
    ) { padding ->
        if (tracks.isEmpty()) {
            EmptyState(Modifier.padding(padding), onAddFiles)
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
                itemsIndexed(tracks, key = { _, t -> t.uri }) { index, track ->
                    val isCurrent = track.uri == ui.mediaId
                    TrackRow(
                        track = track,
                        index = index,
                        count = tracks.size,
                        isCurrent = isCurrent,
                        isPlaying = isCurrent && ui.isPlaying,
                        savedPos = if (isCurrent) 0L else store.getPosition(track.uri),
                        onPlay = onPlay,
                        onRemove = onRemove,
                        onMove = onMove,
                        onShare = onShare,
                    )
                }
            }
        }
    }

    if (showSpeed && player != null) {
        SpeedDialog(
            current = ui.speed,
            onPick = { s -> player.setPlaybackSpeed(s); store.speed = s; showSpeed = false },
            onDismiss = { showSpeed = false }
        )
    }
    if (showSleep) {
        SleepDialog(active = sleepEnd > 0 || sleepAtEnd, onDismiss = { showSleep = false })
    }
    val bookmarkId = ui.mediaId
    if (showBookmarks && player != null && bookmarkId != null) {
        BookmarksDialog(
            store = store,
            mediaId = bookmarkId,
            currentPosition = ui.position,
            onSeek = { player.seekTo(it); if (!player.isPlaying) player.play() },
            onDismiss = { showBookmarks = false }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить список?") },
            text = { Text("Файлы на телефоне не удаляются — только список в плеере.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; onClear() }) { Text("Очистить") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
private fun PlayerPanel(
    player: Player,
    ui: PlayerUi,
    onSpeed: () -> Unit,
    onBookmarks: () -> Unit,
    onShare: () -> Unit,
) {
    val abA by PlaybackExtras.abStart.collectAsState()
    val abB by PlaybackExtras.abEnd.collectAsState()
    var dragging by remember { mutableStateOf<Float?>(null) }
    val primary = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(tonalElevation = 3.dp, shadowElevation = 8.dp) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                ui.title.ifEmpty { "—" },
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            val dur = ui.duration.toFloat().coerceAtLeast(1f)
            Slider(
                value = (dragging ?: ui.position.toFloat()).coerceIn(0f, dur),
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { player.seekTo(it.toLong()) }
                    dragging = null
                },
                valueRange = 0f..dur,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    formatTime(dragging?.toLong() ?: ui.position),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(Modifier.weight(1f))
                if (abA >= 0) {
                    val abText = "A ${formatTime(abA)}" + if (abB >= 0) "  →  B ${formatTime(abB)}" else ""
                    Text(abText, style = MaterialTheme.typography.labelSmall, color = primary)
                }
                Spacer(Modifier.weight(1f))
                Text(formatTime(ui.duration), style = MaterialTheme.typography.labelSmall)
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { player.shuffleModeEnabled = !ui.shuffle }) {
                    Icon(Icons.Default.Shuffle, "Перемешать", tint = if (ui.shuffle) primary else muted)
                }
                IconButton(onClick = { player.seekToPrevious() }) {
                    Icon(Icons.Default.SkipPrevious, "Предыдущий")
                }
                IconButton(onClick = { player.seekBack() }) {
                    Icon(Icons.Default.Replay10, "Назад 10 секунд")
                }
                FilledIconButton(
                    onClick = {
                        if (ui.isPlaying) {
                            player.pause()
                        } else {
                            if (player.playbackState == Player.STATE_IDLE) player.prepare()
                            if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition()
                            player.play()
                        }
                    },
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        if (ui.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if (ui.isPlaying) "Пауза" else "Играть",
                        Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = { player.seekForward() }) {
                    Icon(Icons.Default.Forward10, "Вперёд 10 секунд")
                }
                IconButton(onClick = { player.seekToNext() }) {
                    Icon(Icons.Default.SkipNext, "Следующий")
                }
                IconButton(onClick = {
                    player.repeatMode = when (ui.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }) {
                    Icon(
                        if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Повтор",
                        tint = if (ui.repeatMode == Player.REPEAT_MODE_OFF) muted else primary
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onSpeed) { Text("Скорость ${speedLabel(ui.speed)}") }
                TextButton(onClick = {
                    val pos = player.currentPosition
                    when {
                        abA < 0 -> PlaybackExtras.abStart.value = pos
                        abB < 0 -> if (pos > abA + 500) PlaybackExtras.abEnd.value = pos else PlaybackExtras.clearAb()
                        else -> PlaybackExtras.clearAb()
                    }
                }) {
                    Text(
                        when {
                            abA < 0 -> "A–B"
                            abB < 0 -> "Точка B"
                            else -> "Сброс A–B"
                        },
                        color = if (abA >= 0) primary else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = onBookmarks) { Icon(Icons.Default.Bookmarks, "Закладки") }
                IconButton(onClick = onShare) { Icon(Icons.Default.Share, "Поделиться") }
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track,
    index: Int,
    count: Int,
    isCurrent: Boolean,
    isPlaying: Boolean,
    savedPos: Long,
    onPlay: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onMove: (Int, Int) -> Unit,
    onShare: (Track) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val supporting: (@Composable () -> Unit)? =
        if (savedPos > 0L) {
            { Text("Остановлено на ${formatTime(savedPos)}") }
        } else null

    ListItem(
        modifier = Modifier.clickable { onPlay(index) },
        colors = if (isCurrent) {
            ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        } else {
            ListItemDefaults.colors()
        },
        leadingContent = {
            Icon(
                if (isPlaying) Icons.Default.GraphicEq else Icons.Default.MusicNote,
                contentDescription = null,
                tint = if (isCurrent) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        headlineContent = {
            Text(
                track.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (isCurrent) FontWeight.SemiBold else null
            )
        },
        supportingContent = supporting,
        trailingContent = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Действия") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Поделиться / отправить") },
                        leadingIcon = { Icon(Icons.Default.Share, null) },
                        onClick = { menu = false; onShare(track) }
                    )
                    if (index > 0) {
                        DropdownMenuItem(
                            text = { Text("Выше") },
                            leadingIcon = { Icon(Icons.Default.KeyboardArrowUp, null) },
                            onClick = { menu = false; onMove(index, index - 1) }
                        )
                    }
                    if (index < count - 1) {
                        DropdownMenuItem(
                            text = { Text("Ниже") },
                            leadingIcon = { Icon(Icons.Default.KeyboardArrowDown, null) },
                            onClick = { menu = false; onMove(index, index + 1) }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Убрать из списка") },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = { menu = false; onRemove(index) }
                    )
                }
            }
        }
    )
}

@Composable
private fun EmptyState(modifier: Modifier, onAddFiles: () -> Unit) {
    Column(
        modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.LibraryMusic, null,
            Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.size(16.dp))
        Text("Список пуст", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.size(8.dp))
        Text(
            "Добавьте аудиофайлы с телефона: лекции, уроки, чтение Корана — любые записи.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.size(24.dp))
        Button(onClick = onAddFiles) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.size(8.dp))
            Text("Добавить файлы")
        }
    }
}

@Composable
private fun SpeedDialog(current: Float, onPick: (Float) -> Unit, onDismiss: () -> Unit) {
    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Скорость воспроизведения") },
        text = {
            Column {
                speeds.forEach { s ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(s) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = current == s, onClick = null)
                        Spacer(Modifier.size(12.dp))
                        Text(speedLabel(s))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}

@Composable
private fun SleepDialog(active: Boolean, onDismiss: () -> Unit) {
    val minutes = listOf(5, 10, 15, 20, 30, 45, 60, 90)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Таймер сна") },
        text = {
            LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(minutes) { m ->
                    Text(
                        "$m мин",
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                PlaybackExtras.sleepAtTrackEnd.value = false
                                PlaybackExtras.sleepEndAt.value = SystemClock.elapsedRealtime() + m * 60_000L
                                onDismiss()
                            }
                            .padding(vertical = 12.dp)
                    )
                }
                item {
                    Text(
                        "До конца текущего трека",
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                PlaybackExtras.sleepEndAt.value = 0L
                                PlaybackExtras.sleepAtTrackEnd.value = true
                                onDismiss()
                            }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = {
            if (active) {
                TextButton(onClick = { PlaybackExtras.cancelSleep(); onDismiss() }) { Text("Выключить таймер") }
            } else {
                TextButton(onClick = onDismiss) { Text("Закрыть") }
            }
        }
    )
}

@Composable
private fun BookmarksDialog(
    store: Store,
    mediaId: String,
    currentPosition: Long,
    onSeek: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    var list by remember(mediaId) { mutableStateOf(store.loadBookmarks(mediaId)) }
    var label by remember { mutableStateOf("") }
    val positionAtOpen = remember(mediaId) { currentPosition }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Закладки") },
        text = {
            Column {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Название (необязательно)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val b = Bookmark(positionAtOpen, label.trim(), System.currentTimeMillis())
                        list = (list + b).sortedBy { it.positionMs }
                        store.saveBookmarks(mediaId, list)
                        label = ""
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Icon(Icons.Default.BookmarkAdd, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Добавить на ${formatTime(positionAtOpen)}")
                }
                Spacer(Modifier.size(12.dp))
                if (list.isEmpty()) {
                    Text("Закладок пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(list, key = { it.createdAt }) { b ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { onSeek(b.positionMs); onDismiss() }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    formatTime(b.positionMs),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.width(72.dp)
                                )
                                Text(b.label.ifEmpty { "Закладка" }, Modifier.weight(1f))
                                IconButton(onClick = {
                                    list = list - b
                                    store.saveBookmarks(mediaId, list)
                                }) {
                                    Icon(Icons.Default.Delete, "Удалить закладку")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
