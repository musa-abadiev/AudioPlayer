package com.audioplayer.app

import android.Manifest
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.audioplayer.app.ui.AppTheme
import com.audioplayer.app.ui.PlayerScreen
import java.util.concurrent.Future

class MainActivity : ComponentActivity() {

    private lateinit var store: Store
    private val tracks = mutableStateOf<List<Track>>(emptyList())
    private val controller = mutableStateOf<MediaController?>(null)
    private var controllerFuture: Future<MediaController>? = null
    private var pendingUris: List<Uri> = emptyList()

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) addUris(uris, playFirst = false)
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        store = Store(this)
        tracks.value = store.loadTracks()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        handleIntent(intent)

        setContent {
            AppTheme {
                PlayerScreen(
                    player = controller.value,
                    tracks = tracks.value,
                    store = store,
                    onAddFiles = { pickAudio.launch(arrayOf("audio/*")) },
                    onPlay = ::play,
                    onRemove = ::removeTrack,
                    onMove = ::moveTrack,
                    onClear = ::clearAll,
                    onShare = ::shareTrack,
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            val c = try {
                future.get()
            } catch (e: Exception) {
                null
            } ?: return@addListener
            onControllerReady(c)
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller.value = null
        super.onStop()
    }

    private fun onControllerReady(c: MediaController) {
        syncPlaylist(c)
        controller.value = c
        if (pendingUris.isNotEmpty()) {
            val uris = pendingUris
            pendingUris = emptyList()
            addUris(uris, playFirst = true)
        }
    }

    /** Приводит очередь плеера в соответствие с сохранённым списком. */
    private fun syncPlaylist(c: MediaController) {
        val want = tracks.value
        val have = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }
        if (have == want.map { it.uri }) return

        when {
            want.isEmpty() -> c.clearMediaItems()
            have.isEmpty() -> {
                val index = store.lastIndex.coerceIn(0, want.size - 1)
                c.setMediaItems(
                    want.map { it.toMediaItem() }, index, store.getPosition(want[index].uri)
                )
                c.prepare()
            }
            want.size > have.size && want.take(have.size).map { it.uri } == have -> {
                c.addMediaItems(want.drop(have.size).map { it.toMediaItem() })
            }
            else -> {
                val curId = c.currentMediaItem?.mediaId
                val wasPlaying = c.playWhenReady
                val newIndex = want.indexOfFirst { it.uri == curId }
                c.setMediaItems(
                    want.map { it.toMediaItem() },
                    newIndex.coerceAtLeast(0),
                    if (newIndex >= 0) c.currentPosition else 0L
                )
                c.prepare()
                c.playWhenReady = wasPlaying
            }
        }
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val uris: List<Uri> = when (intent.action) {
            Intent.ACTION_VIEW -> listOfNotNull(intent.data)
            Intent.ACTION_SEND -> listOfNotNull(
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            )
            else -> emptyList()
        }
        if (uris.isEmpty()) return
        intent.action = null // не обрабатывать повторно при повороте экрана
        if (controller.value != null) addUris(uris, playFirst = true) else pendingUris = uris
    }

    private fun addUris(uris: List<Uri>, playFirst: Boolean) {
        val existing = tracks.value.map { it.uri }.toSet()
        val newTracks = uris.mapNotNull { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val s = uri.toString()
            if (s in existing) null else Track(s, displayName(uri))
        }.distinctBy { it.uri }

        if (newTracks.isNotEmpty()) {
            tracks.value = tracks.value + newTracks
            store.saveTracks(tracks.value)
            controller.value?.addMediaItems(newTracks.map { it.toMediaItem() })
        }
        if (playFirst) {
            val index = tracks.value.indexOfFirst { it.uri == uris.first().toString() }
            if (index >= 0) play(index)
        }
    }

    private fun play(index: Int) {
        val c = controller.value ?: return
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        if (index == c.currentMediaItemIndex) {
            if (c.isPlaying) c.pause() else c.play()
            return
        }
        c.seekToDefaultPosition(index)
        c.play()
    }

    private fun removeTrack(index: Int) {
        val list = tracks.value.toMutableList()
        if (index !in list.indices) return
        list.removeAt(index)
        tracks.value = list
        store.saveTracks(list)
        controller.value?.removeMediaItem(index)
    }

    private fun moveTrack(from: Int, to: Int) {
        val list = tracks.value.toMutableList()
        if (from !in list.indices || to !in list.indices) return
        list.add(to, list.removeAt(from))
        tracks.value = list
        store.saveTracks(list)
        controller.value?.moveMediaItem(from, to)
    }

    private fun clearAll() {
        tracks.value = emptyList()
        store.saveTracks(emptyList())
        PlaybackExtras.clearAb()
        controller.value?.clearMediaItems()
    }

    private fun shareTrack(track: Track) {
        val uri = Uri.parse(track.uri)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = contentResolver.getType(uri) ?: "audio/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, track.title)
            clipData = ClipData.newRawUri(track.title, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(send, "Отправить «${track.title}»"))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось отправить файл", Toast.LENGTH_SHORT).show()
        }
    }
}
